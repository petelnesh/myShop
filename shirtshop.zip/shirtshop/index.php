<!DOCTYPE>
<?php
session_start();
include("functions/functions.php");


?>
<html>
<head>
	<title>My online Shop</title>
	<link rel="stylesheet" type="text/css" href="styles/animate.css" media="all">
	<link rel="stylesheet" type="text/css" href="styles/styles.css" media="all">
    	<link href="styles/bootstrap.min.css" rel="stylesheet">
    	<link href="styles/bootstrap.min.css" rel="stylesheet">

 <script src="js/html5shiv.js"></script>
      <script src="js/respond.min.js"></script>
             <script src="js/jquery-1.11.3.min.js"></script>
		<script src="js/bootstrap.js"></script>

</head>
</head>
<body >
  <div class="wrapper">
    
	<div class="main_wrapper">
    <div id="callout">
       <div id="form">
  <form method="get" action="results.php" "multipart/form-data" >
      <input type="text" name="user_query" placeholder="Search a product"/>
      <input type="submit" name="search" value="search"/>
    </form></div>
      <p>Call us at <b>0708-529-798</b></p></div>
	<!--main header-->
<div class="header_wrapper">

	<div class="container">
	<img id="banner" src="images/kush.jpg"  height="70"/>
  <a href="index.php"><img id="logo" src="images/m.png" height="70"/></a>
</div>
</div>
    <div class="navbar">
    <ul>    
    <li><a href="index.php">Home</a></li>
    <li><a href="all_products.php">All Products</a></li>
    <li><a href="customers/my_account.php">My Account</a></li>
    <li><a href="#">Sign Up</a></li>
    <li><a href="cart.php">Shopping Cart</a></li>
    <li><a href="#">Contact Us</a></li>
   
 </ul>
</div>


<div class="content">
  <?php cart(); ?>
  <div class="row">
   <div id="shopping_cart" data-toggle="collapse" data-target="#collapseExample" aria-expanded="false" aria-controls="collapseExample">
    <span style="float:right;font-size: 18px; padding:5px; line-height:40px;">

   <?php
         if(isset($_SESSION['customer_email'])){
echo "<b>Welcome:</b>" .$_SESSION['customer_email']."<b style='color:yellow;'>Your</b>";

         }
         else{
         	echo "<b>Welcome Guest:</b>";
         }

         ?>
 
 
       <b style="color:yellow">Shopping cart-</b>Total Items:<?php total_items(); ?> Total Price: <?php total_price(); ?><a href="cart.php" style="color:yellow">Go to Cart</a>

   <?php
              if(!isset($_SESSION['customer_email'])){
              	echo "<a href='checkout.php' style='color:orange;'>Login</a>";
              }
              else{
              	echo "<a href='logout.php' style='color:orange;'>Logout</a>";
              }

              ?></span>
  </div>
</div>

  <?php getIp(); ?>

	<p class="text animated bounceInLeft"></p>
	<div id="product_box">
 <?php getPro();
    	?>

    	
    </div>
	</div>


<footer>
  <div class="section">
    <ul>
    <li><a href="index.php">Home</a></li><br>
    <li><a href="all_products.php">All Products</a></li><br>
    <li><a href="customers/my_account.php">My Account</a></li><br>
    <li><a href="#">Sign Up</a></li><br>
    <li><a href="cart.php">Shopping Cart</a></li><br>
    <li><a href="#">Contact Us</a></li><br>
  </ul>
  </div>
  <div class="section">
    <img src="images/logo/facebook.jpg" height="50" width="50">
    <img src="images/logo/twitter.jpg" height="50" width="50">
    <img src="images/logo/youtube.jpg" height="50" width="50">
    <img src="images/logo/ebay.jpg" height="50" width="50">
  </div>
  <div class="section">
    <img id="logo1" src="images/m.png" height="70"/>
  </div>

</footer>
</div>

<p style="text-align:center; padding:0px; color:#878E63; font-size:18px;"><i>&copy;2015 by peterson9munene@gmail.com</i></p>
</div>
</body> 


</html>
