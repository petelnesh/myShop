<?php

session_start();

include("includes/db.php");
include("functions/functions.php");

if(isset($_POST['login'])){
	$email=mysql_real_escape_string($_POST['email']);
	$pass=mysql_real_escape_string($_POST['password']);

	$sel_user="select * from admins where user_email='$email' AND user_password='$pass'";
   
    $run_user=mysqli_query($con,$sel_user);

  $check_user=mysqli_num_rows($run_user);

    if($check_user==1){
    	$_SESSION['user_email']=$email;

    	echo "<script>window.open('index.php?logged_in=you have successifully logged in!','_self')</script>";
    	
    }
    else{
    	"<script>window.open('index.php?logged_in=you have successifully logged in!','_self')</script>";
    	
    }

}

?>