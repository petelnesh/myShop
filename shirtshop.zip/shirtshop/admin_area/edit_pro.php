<!DOCTYPE>
<?php

include("includes/db.php");

if(isset($_GET['edit_pro'])){

$get_id=$_GET['edit_pro'];
$get_pro="select * from products where product_id='$get_id'";

	$run_pro=mysqli_query($con,$get_pro);

	$i=0;

	$row_pro=mysqli_fetch_array($run_pro);

		$pro_id=$row_pro['product_id'];
		$pro_image=$row_pro['product_image'];
		$pro_price=$row_pro['product_price'];
		$pro_desc=$row_pro['product_desc'];
		$pro_keywords=$row_pro['product_desc'];
		

		$get_cat="select * from products where product_id='$pro_id'";

		$run_cat=mysqli_query($con,$get_cat);

		$row_cat=mysqli_fetch_array($run_cat);

		

}
?>
<html>
<head>
<title>Update Product</title>
</head>
<body bgcolor="skyblue">

<form action="insert_product.php" method="post" enctype="multipart/form-data">

	<table align="center" width="795" border="2" bgcolor="#187eae">
		<tr align="center">
			<td colspan="7"><h2>Edit & Update product</h2></td>
		</tr>
	
		
		<tr>
			<td align="right"><b>Product Image:</b></td>
			<td><input type="file" name="product_image"/><img src="images/<?php echo $pro_image; ?>" width="60" height="60"/></td>
		</tr>
		<tr>
			<td align="right"><b>Product Price:</b></td>
			<td><input type="text" name="product_price" value="<?php echo $pro_price; ?>"/></td>
		</tr>
		<tr>
			<td align="right"><b>Product Description:<b></td>
			<td><textarea name="product_desc" cols="20" rows="10"><?php echo $pro_desc; ?></textarea></td>
		</tr>
		<tr>
			<td align="right"><b>Product Keywords: </b></td>
			<td><input type="text" name="product_keywords" size="50" value="<?php echo $pro_keywords; ?>"/></td>
		</tr>
		<tr align="center">
		
			<td colspan="7"><input type="submit" name="update_product" value="Update product "/></td>
		</tr>                      
	</table>
</form>

</body>
</html>

<?php

  if(isset($_POST['insert_post'])){
 
 //getting the text data from fields
$product_price=$_POST['product_price'];
$product_desc=$_POST['product_desc'];
$product_keywords=$_POST['product_keywords'];

      //getting the image data from fields
     $product_image=$_FILES['product_image']['name'];
     $product_image_tmp=$_FILES['product_image']['tmp_name'];

      move_uploaded_file($product_image_tmp, "product_images/$product_image");


     $insert_product="insert into products (product_price,product_desc,product_image,product_keywords)
     values('$product_price','$product_desc','$product_image','$product_keywords')";


      $insert_pro=mysqli_query($con,$insert_product);

      if($insert_pro){
      	echo "<script>alert('Product has been Inserted!')</script>";
      	echo "<script>window.open('index.php?insert_product','_self')</script>";
      }
   
  }

?>  
