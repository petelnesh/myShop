<!DOCTYPE>
<?php
session_start();
include("functions/functions.php");


?>
<html>
<head>
	<title>My online Shop</title>
	<link rel="stylesheet" type="text/css" href="styles/animate.css" media="all">
	<link rel="stylesheet" type="text/css" href="styles/styles.css" media="all">
    	<link href="styles/bootstrap.min.css" rel="stylesheet">
    	<link href="styles/bootstrap.min.css" rel="stylesheet">

 <script src="js/html5shiv.js"></script>
      <script src="js/respond.min.js"></script>
             <script src="js/jquery-1.11.3.min.js"></script>
		<script src="js/bootstrap.js"></script>

</head>
</head>
<body>
    <div class="wrapper">
	<div class="main_wrapper">
    
    <div id="callout">
       <div id="form">
  <form method="get" action="results.php" "multipart/form-data" >
      <input type="text" name="user_query" placeholder="Search a product"/>
      <input type="submit" name="search" value="search"/>
    </form></div>
      <p>Call us at <b>0708-529-798</b></p></div>
	<!--main header-->
<div class="header_wrapper">

	<a href="index.php"><img id="logo" src="images/m.png" height="70"/></a>
	<img id="banner" src="images/kush.jpg"  height="70"/>
</div>
<div class="navbar">
	<ul >
		<li><a href="index.php">Home</a></li>
		<li><a href="all_products.php">All Products</a></li>
		<li><a href="customers/my_account.php">My Account</a></li>
		<li><a href="#">Sign Up</a></li>
		<li><a href="cart.php">Shopping Cart</a></li>
		<li><a href="#">Contact Us</a></li>

	</ul>
</div>
<div class="content">
  <?php cart(); ?>
 
  <div id="shopping_cart">
    <span style="float:right;font-size: 18px; padding:5px; line-height:40px;">
      Welcome Guest! <b style="color:yellow">Shopping cart-</b>Total Items:<?php total_items(); ?> Total Price: <?php total_price(); ?><a href="cart.php" style="color:yellow">Go to Cart</a></span>
  </div>
  <?php getIp(); ?>
	<p class="text animated bounceInLeft"></p>
	<div id="product_box">
    <?php
 
 $get_prod="select * from products ";

    $run_prod=mysqli_query($con,$get_prod);

    while($row_prod=mysqli_fetch_array($run_prod)){

        $pro_id=$row_prod['product_id'];
       
        $pro_price=$row_prod['product_price'];
        $pro_image=$row_prod['product_image'];

        echo "
          <div id='single_product'>
          
          <img src='admin_area/images/$pro_image' width='180' height='180' class='im img-responsive'/>

       <p><b>Price: Ksh $pro_price </b></p>

       <a href='details.php?pro_id=$pro_id' style='float:left;'>Details</a>

       <a href='index.php?add_cart=$pro_id'><button style='float:right ;color:#878E63'>Add to Cart</button></a>
          </div>

        ";
    
}
?>
    	
    </div>
	
</div>

<footer>
  <div class="section">
    <ul>
    <li><a href="index.php">Home</a></li><br>
    <li><a href="all_products.php">All Products</a></li><br>
    <li><a href="customers/my_account.php">My Account</a></li><br>
    <li><a href="#">Sign Up</a></li><br>
    <li><a href="cart.php">Shopping Cart</a></li><br>
    <li><a href="#">Contact Us</a></li><br>
  </ul>
  </div>
  <div class="section">
    <img src="images/logo/facebook.jpg" height="50" width="50">
    <img src="images/logo/twitter.jpg" height="50" width="50">
    <img src="images/logo/youtube.jpg" height="50" width="50">
    <img src="images/logo/ebay.jpg" height="50" width="50">
  </div>
  <div class="section">
    <img id="logo1" src="images/m.png" height="70"/>
  </div>

</footer>
</div>

<p style="text-align:center; padding:0px; color:#878E63; font-size:18px;"><i>&copy;2015 by peterson9munene@gmail.com</i></p>

</body> 
</html>
