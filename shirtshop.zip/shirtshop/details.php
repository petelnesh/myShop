<!DOCTYPE>
<?php
session_start();
include("functions/functions.php");


?>
<html>
<head>
	<title>My online Shop</title>
	<link rel="stylesheet" type="text/css" href="styles/animate.css" media="all">
	<link rel="stylesheet" type="text/css" href="styles/styles.css" media="all">
    	<link href="styles/bootstrap.min.css" rel="stylesheet">
    	<link href="styles/bootstrap.min.css" rel="stylesheet">

 <script src="js/html5shiv.js"></script>
      <script src="js/respond.min.js"></script>
             <script src="js/jquery-1.11.3.min.js"></script>
		<script src="js/bootstrap.js"></script>

</head>
</head>
<body>
	<div class="main_wrapper">
	<!--main header-->
<div class="header_wrapper">

	<a href="index.php"><img id="logo" src="images/m.png" height="70"/></a>
	<img id="banner" src="images/kush.jpg"  height="70"/>
</div>
<div class="menubar">
	<ul id="menu">
		<li><a href="index.php">Home</a></li>
		<li><a href="all_products.php">All Products</a></li>
		<li><a href="customers/my_account.php">My Account</a></li>
		<li><a href="#">Sign Up</a></li>
		<li><a href="cart.php">Shopping Cart</a></li>
		<li><a href="#">Contact Us</a></li>
		<li><div id="form">
	<form method="get" action="results.php" "multipart/form-data" >
			<input type="text" name="user_query" placeholder="Search a product"/>
			<input type="submit" name="search" value="search"/>
		</form></div></li>
	</ul>
</div>
<div class="content">
  <?php cart(); ?>
   <div id="shopping_cart">
    <span style="float:right;font-size: 18px; padding:5px; line-height:40px;">

   <?php
         if(isset($_SESSION['customer_email'])){
echo "<b>Welcome:</b>" .$_SESSION['customer_email']."<b style='color:yellow;'>Your</b>";

         }
         else{
         	echo "<b>Welcome Guest:</b>";
         }

         ?>
 
 
       <b style="color:yellow">Shopping cart-</b>Total Items:<?php total_items(); ?> Total Price: <?php total_price(); ?><a href="cart.php" style="color:yellow">Go to Cart</a>

   <?php
              if(!isset($_SESSION['customer_email'])){
              	echo "<a href='checkout.php' style='color:orange;'>Login</a>";
              }
              else{
              	echo "<a href='logout.php' style='color:orange;'>Logout</a>";
              }

              ?></span>
  </div>
  <?php getIp(); ?>
	<p class="text animated bounceInLeft"></p>
	<div id="product_box">
 <?php

      if(isset($_GET['pro_id'])){

        $product_id=$_GET['pro_id'];
              $get_pro="select * from products where product_id='$product_id'";

    $run_pro=mysqli_query($con,$get_pro);

    while($row_pro=mysqli_fetch_array($run_pro)){

        $pro_id=$row_pro['product_id'];
        $pro_price=$row_pro['product_price'];
        $pro_image=$row_pro['product_image'];
        $pro_desc=$row_pro['product_desc'];

        echo "
          <div id='single_product'>
          <img src='admin_area/images/$pro_image' width='400' height='300' />

       <p><b> $ $pro_price </b></p>
       <p>$pro_desc</p>


       <a href='index.php' style='float:left;'>Go Back</a>

       <a href='index.php?pro_id=$pro_id'><button style='float:right'>Add to Cart</button></a>
          </div>

        ";
    }
}
      ?>

    	
    </div>
	
</div>



</body> 
</html>
