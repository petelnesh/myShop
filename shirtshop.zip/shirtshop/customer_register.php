<!DOCTYPE>
<?php
session_start();
include("functions/functions.php");


?>
<html>
<head>
	<title>My online Shop</title>
	<link rel="stylesheet" type="text/css" href="styles/animate.css" media="all">
	<link rel="stylesheet" type="text/css" href="styles/styles.css" media="all">
    	<link href="styles/bootstrap.min.css" rel="stylesheet">
    	<link href="styles/bootstrap.min.css" rel="stylesheet">

 <script src="js/html5shiv.js"></script>
      <script src="js/respond.min.js"></script>
             <script src="js/jquery-1.11.3.min.js"></script>
		<script src="js/bootstrap.js"></script>

</head>
</head>
<body>
	<div class="wrapper">
	<div class="main_wrapper">
		 <div id="callout">
       <div id="form">
  <form method="get" action="results.php" "multipart/form-data" >
      <input type="text" name="user_query" placeholder="Search a product"/>
      <input type="submit" name="search" value="search"/>
    </form></div>
      <p>Call us at <b>0708-529-798</b></p></div>
	<!--main header-->
<div class="header_wrapper">

	<a href="index.php"><img id="logo" src="images/m.png" height="70"/></a>
	<img id="banner" src="images/kush.jpg"  height="70"/>
</div>
<div class="navbar">
	<ul >
		<li><a href="index.php">Home</a></li>
		<li><a href="all_product.php">All Products</a></li>
		<li><a href="customers/my_account.php">My Account</a></li>
		<li><a href="#">Sign Up</a></li>
		<li><a href="cart.php">Shopping Cart</a></li>
		<li><a href="#">Contact Us</a></li>
	
</div>
<div class="content">
  <?php cart(); ?>
 
  <div id="shopping_cart">
    <span style="float:right;font-size: 18px; padding:5px; line-height:40px;">
      Welcome Guest! <b style="color:yellow">Shopping cart-</b>Total Items:<?php total_items(); ?> Total Price: <?php total_price(); ?><a href="cart.php" style="color:yellow">Go to Cart</a></span>
  </div>
  <?php getIp(); ?>
	<p class="text animated bounceInLeft"></p>
	
<div class="fomi">
<form  id="form1" action="customer_register.php" method="post" enctype="multipart/form-data">

<table align="center" width="750">
	<tr align="center">
		<td colspan="5"><h2>Creating an Account</h2></td>
	</tr>
	<tr>
		<td align="right">Customer Name:</td>
		<td><input type="text" name="c_name" /></td>

	</tr>
	<tr>
		<td align="right">Customer Email:</td>
		<td><input type="text" name="c_email" /></td>

	</tr>
	<tr>
		<td align="right">Customer Password</td>
		<td><input type="password" name="c_pass"/></td>

	</tr>

	<tr>
		<td align="right">Customer Image</td>
		<td><input type="file" name="c_image"/></td>

	</tr>
	<tr>
		<td align="right">Customer Country</td>
		<td>
			<select name="c_country">
				<option>Select a Country</option>
				<option>kenya</option>
				<option>uganda</option>
				<option>brazil</option>
				<option>usa</option>
				<option>japan</option>
				<option>egypt</option>
				<option>tanzania</option>
				<option>ethiopia</option>
				<option>somalia</option>
				<option>china</option>
				<option>south africa</option>
				<option>malawi</option>
				<option>congo</option>
				</select></td>

	</tr>
	<tr>
		<td align="right">Customer City:</td>
		<td><input type="text" name="c_city"/></td>

	</tr>
	<tr>
		<td align="right">Customer Contact:</td>
		<td><input type="text" name="c_contact"/></td>

	</tr>
		<tr>
		<td align="right">Customer Address:</td>
		<td><input type+"text" name="c_address"></td>
 
	</tr>

<tr align="center">
	<td colspan="6"><input type="submit" name="register" value="Create Account"/></td>

</tr>

</table>
          </form>
          </div>
          <footer>
  <div class="section">
    <ul>
    <li><a href="index.php">Home</a></li><br>
    <li><a href="all_products.php">All Products</a></li><br>
    <li><a href="customers/my_account.php">My Account</a></li><br>
    <li><a href="#">Sign Up</a></li><br>
    <li><a href="cart.php">Shopping Cart</a></li><br>
    <li><a href="#">Contact Us</a></li><br>
  </ul>
  </div>
  <div class="section">
    <img src="images/logo/facebook.jpg" height="50" width="50">
    <img src="images/logo/twitter.jpg" height="50" width="50">
    <img src="images/logo/youtube.jpg" height="50" width="50">
    <img src="images/logo/ebay.jpg" height="50" width="50">
  </div>
  <div class="section">
    <img id="logo1" src="images/m.png" height="70"/>
  </div>

</footer>
</div>

<p style="text-align:center; padding:0px; color:#878E63; font-size:18px;"><i>&copy;2015 by peterson9munene@gmail.com</i></p>

    	</div>
    </div>
	
</div>


</body> 
</html>
<?php

if(isset($_POST['register'])){
	$ip=getIp();

	$c_name=$_POST['c_name'];
	$c_email=$_POST['c_email'];
	$c_pass=$_POST['c_pass'];
	$c_country=$_POST['c_country'];
	$c_city=$_POST['c_city'];
	$c_contact=$_POST['c_contact'];
	$c_address=$_POST['c_address'];

	  $c_image=$_FILES['c_image']['name'];
       $c_image_tmp=$_FILES['c_image']['tmp_name'];

   move_uploaded_file($c_image_tmp, "customers/customer_images/$c_image");

	$insert_c="insert into customers (customer_ip,customer_name,customer_email,customer_pass,customer_country,customer_city,customer_contact,customer_address,customer_image) values('$ip','$c_name','$c_email','$c_pass','$c_country','$c_city','$c_contact','$c_address','$c_image')";
	$run_c=mysqli_query($con,$insert_c);

$sel_cart="select * from cart where ip_add='$ip'";

$run_cart=mysqli_query($con,$sel_cart);

$check_cart=mysqli_num_rows($run_cart);

if($check_cart==0){

	$_SESSION['customer_email']=$c_email;
	echo "<script>alert('Account has been created successifully, Thanks!')</script>";
   echo "<script>window.open('customer/my_account.php','_self')</script>";

}
else{
	$_SESSION['customer_email']=$c_email;
	echo "<script>alert('Account has been created successifully, Thanks!')</script>";
   echo "<script>window.open('checkout.php','_self')</script>";

}
}
?>