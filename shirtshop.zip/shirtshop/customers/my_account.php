<!DOCTYPE>
<?php
session_start();
include("functions/functions.php");


?>
<html>
<head>
	<title>My online Shop</title>
	<link rel="stylesheet" type="text/css" href="styles/animate.css" media="all">
	<link rel="stylesheet" type="text/css" href="styles/styles.css" media="all">
    	<link href="styles/bootstrap.min.css" rel="stylesheet">
    	<link href="styles/bootstrap.min.css" rel="stylesheet">

 <script src="js/html5shiv.js"></script>
      <script src="js/respond.min.js"></script>
             <script src="js/jquery-1.11.3.min.js"></script>
		<script src="js/bootstrap.js"></script>

</head>
</head>
<body>
    <div class="wrapper">
	<div class="main_wrapper">
	<!--main header-->
	<div id="callout">
       <div id="form">
  <form method="get" action="results.php" "multipart/form-data" >
      <input type="text" name="user_query" placeholder="Search a product"/>
      <input type="submit" name="search" value="search"/>
    </form></div>
      <p>Call us at <b>0708-529-798</b></p></div>
<div class="header_wrapper">

	<a href="index.php"><img id="logo" src="images/m.png" height="70"/></a>
	<img id="banner" src="images/kush.jpg"  height="70"/>
</div>
<div class="navbar">
	<ul>
		<li><a href="../index.php">Home</a></li>
		<li><a href="../all_products.php">All Products</a></li>
		<li><a href="customers/my_account.php">My Account</a></li>
		<li><a href="#">Sign Up</a></li>
		<li><a href="../cart.php">Shopping Cart</a></li>
		<li><a href="#">Contact Us</a></li>
	
	</ul>
</div>

<div class="content">
  <?php cart(); ?>
 
  <div id="shopping_cart">
    <span style="float:right;font-size: 18px; padding:5px; line-height:40px;">

   <?php
         if(isset($_SESSION['customer_email'])){
echo "<b>Welcome:</b>" .$_SESSION['customer_email']
;
         }

         ?>
         <?php
              if(!isset($_SESSION['customer_email'])){
                echo "<a href='checkout.php' style='color:orange;'>Login</a>";
              }
              else{
                echo "<a href='logout.php' style='color:orange;'>Logout</a>";
              }

              ?>
      </span>
  </div>
  <?php getIp(); ?>
	<p class="text animated bounceInLeft"></p>
	<div id="product_box">
<div id="sidebar">
<h2>My Account</h2>

<ul id="cats">
	<?php
	$user=$_SESSION['customer_email'];

	$get_img="select * from customers where customer_email='$user'";

	$run_img=mysqli_query($con,$get_img);

	$row_img=mysqli_fetch_array($run_img);

	$u_image=$row_img['customer_image'];
	$u_name=$row_img['customer_name'];

	echo "<p style='text-align:center;'><img src='customer_images/$u_image' width='150' height='150'/>";

	?>

<li><a href="my_account.php?my_orders">My Orders</a></li>
<li><a href="my_account.php?edit_account">Edit Account</a></li>
<li><a href="my_account.php?change_pass">Change Password</a></li>
<li><a href="my_account.php?delete_account">Delete Account</a></li>
<li><a href="logout.php">Logout</a></li>
</ul>

</div>

    
    <?php 
    if(!isset($_GET['my_orders'])){
	if(!isset($_GET['edit_account'])){
		if(!isset($_GET['change_pass'])){
			if(!isset($_GET['delete_account'])){

    echo " <h2 style='padding:20px;'>Welcome: <?php echo $u_name;</h2>	<br>
    <b>You can see your orders progress by clicking this<a href='my_account.php?my_orders'> link</b>";
}
}
}
}
?>
<?php

if(isset($_GET['edit_account'])){

	include("edit_account.php");
}
if(isset($_GET['change_pass'])){

	include("change_pass.php");
}
if(isset($_GET['delete_account'])){

	include("delete_account.php");
}
?>
   
	
</div>


<footer>
  <div class="section">
    <ul>
    <li><a href="index.php">Home</a></li><br>
    <li><a href="all_products.php">All Products</a></li><br>
    <li><a href="customers/my_account.php">My Account</a></li><br>
    <li><a href="#">Sign Up</a></li><br>
    <li><a href="cart.php">Shopping Cart</a></li><br>
    <li><a href="#">Contact Us</a></li><br>
  </ul>
  </div>
  <div class="section">
    <img src="../images/logo/facebook.jpg" height="50" width="50">
    <img src="../images/logo/twitter.jpg" height="50" width="50">
    <img src="../images/logo/youtube.jpg" height="50" width="50">
    <img src="../images/logo/ebay.jpg" height="50" width="50">
  </div>
  <div class="section">
    <img id="logo1" src="images/m.png" height="70"/>
  </div>

</footer>
</div>

<p style="text-align:center; padding:0px; color:#878E63; font-size:18px;"><i>&copy;2015 by peterson9munene@gmail.com</i></p>

</body> 
</html>
